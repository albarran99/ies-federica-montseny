public class bucleMedia{
    static double mimetodo(double[] media) {
        double a = 0;
        for (double numero : media) {
            a = a + numero;
        }
        return a / media.length;
    }

    public static void main(String[] args) {
        double[] numeros = new double[args.length];
        if (args.length > 0) {
            for (int bb = 0; bb < args.length; bb++) {
                double numero = Double.parseDouble(args[bb]); numeros[bb] = numero;
            }
            double media = mimetodo(numeros); System.out.println("La media es " + media);
        } else {
            System.out.println("Añade los argumentos");
        }
    }
}
