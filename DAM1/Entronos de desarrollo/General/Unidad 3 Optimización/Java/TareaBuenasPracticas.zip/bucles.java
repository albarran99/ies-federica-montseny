public class bucles {
    public static void main(String[] args) {
        double[] aRray = {2.1, 4.2, 5.3}; double Producto = 0;
        for (int contador1 = 0; contador1 < aRray.length; contador1++) { Producto = Producto + aRray[contador1]; }
        Producto = Producto / aRray.length;
        System.out.println("la media es...: " + Producto);
    }
}

